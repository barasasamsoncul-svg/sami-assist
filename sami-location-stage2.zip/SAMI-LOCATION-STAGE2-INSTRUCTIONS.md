# SaMi Runner — Location Stage 2

## What this stage adds

This stage connects the already verified SurfaceView Mapbox renderer to one SaMi-owned live-location pipeline.

- Expo Location is the only source of device GPS fixes.
- Expo TaskManager receives the same location stream while the Runner is using the app and while the app is in the background, subject to OS permissions and operating-system lifecycle limits.
- Eligible fixes are sent through the existing authenticated `POST /api/runner/location` client.
- The visible dashboard subscribes to those same fixes and sends them into Mapbox through `SaMiMapboxLocationProvider`.
- Mapbox's location component uses the injected SaMi provider. It does not start a second GPS feed.
- SurfaceView is fixed for production. The map-lab SurfaceView/TextureView switch is removed.
- The Dashboard's Go Online action explains and requests background permission before it asks the backend to make the Runner available.
- Going offline or signing out stops the location task.
- When the Runner is already online or has a trackable accepted/in-progress errand at dashboard startup, the app attempts to resume the registered location task.
- The dashboard's locate button gets a fresh position if needed and explicitly recentres the map.
- The map camera automatically follows when the Runner is online or working on a trackable errand, unless the dashboard is covered by another screen.

Navigation route calculation, map matching, turn-by-turn instructions and voice are deliberately not enabled in this stage. This stage connects live location and puck/camera behaviour only.

## Safety and privacy behaviour

- The task publishes only when the explicit tracking-enabled marker is present in SecureStore. Stopping tracking clears this marker before asking the OS to stop location updates.
- The task never logs GPS coordinates or session credentials.
- The task uses the current Runner session from SecureStore and the existing API client; it does not copy tokens into the native Mapbox module.
- Background permission is requested only after the user chooses Go Online and accepts an explanation. If permission is denied, SaMi does not complete the online transition.
- Android displays a foreground-service notification during live tracking.
- Android/iOS may suspend or stop location updates under force-stop, user termination, power-management or permission restrictions. The app attempts to resume a registered task when it is opened again; do not promise tracking after a force-stop.
- The Runner should go offline when a shift is over. Do not rely on app closure as the way to stop location sharing.

## Apply the bundle

The user owns local repository changes. The script checks that the active branch is `main`, permits only the new bundle files to be untracked, validates every source anchor before it writes any existing file, and never commits or pushes.

Copy the downloaded `sami-location-stage2.zip` into `C:\dev\sami-assist-web` first. Then run from PowerShell:

```powershell
cd C:\dev\sami-assist-web

Expand-Archive .\sami-location-stage2.zip -DestinationPath . -Force
node .\apps\runner\scripts\apply-sami-location-stage2.mjs

git diff --check
git status --short
```

If the script reports an unexpected working-tree change or a missing patch anchor, stop and send the complete error. It intentionally does not partially write files when an anchor is missing.

## Install the SDK-matched task manager

```powershell
cd C:\dev\sami-assist-web\apps\runner
npx expo install expo-task-manager
npm run typecheck
```

The command updates `apps/runner/package-lock.json` to the matching Expo SDK 58 version. Do not hand-edit the lockfile.

## Build a local Android Release APK

```powershell
cd C:\dev\sami-assist-web\apps\runner\android
.\gradlew.bat assembleRelease
```

This stage adds Kotlin native Mapbox Location integration and Expo TaskManager, so a new native Release APK is required. An OTA update cannot add these native classes.

Install the APK:

```powershell
adb install -r ".\app\build\outputs\apk\release\app-release.apk"
```

## Device acceptance tests

Perform the first tests while stationary and safely away from traffic.

1. Open the isolated `samirunner://mapbox-lab` screen. Confirm the map renders and the day/night style switch still works. There is no surface-switch control in this screen anymore.
2. Open the Runner dashboard while offline. Tap Locate Me. Grant foreground location permission if asked. Confirm the puck appears at the device's actual position and the camera recentres.
3. Tap Go Online. Read the background-location explanation and choose Continue. Grant foreground and background location permission. On Android versions that open Settings, select **Allow all the time**, then return to SaMi Runner.
4. Confirm the Runner becomes online and Android shows the SaMi location foreground-service notification.
5. Leave SaMi in the background for a short stationary test, then return. Confirm the map is still visible, the current-location state refreshes and the map remains usable.
6. Tap Go Offline. Confirm the foreground-service notification stops and location sharing is no longer active.
7. Sign out. Confirm the location task is stopped before the session is cleared.
8. Navigate away from the dashboard and return. Confirm the map is still visible and the location puck is restored when a current fix is available.

If any test fails, send the full typecheck/build error or the exact visible behaviour before changing more files. Do not share a Mapbox secret token; redact it from logs.

## Files in this bundle

New files:

- `apps/runner/src/location/runner-location-service.ts`
- `apps/runner/modules/sami-mapbox/android/src/main/java/com/sami/runner/mapbox/SaMiMapboxLocationProvider.kt`
- `apps/runner/modules/sami-mapbox/android/src/main/java/com/sami/runner/mapbox/SaMiMapboxLocationController.kt`
- `apps/runner/scripts/apply-sami-location-stage2.mjs`

The apply script updates the existing Mapbox Expo module, its TypeScript public API, the isolated map-lab screen, the Runner dashboard, the root Expo Router layout and the Runner package manifest. It does not change `app.json`, `app.config.ts`, the Mapbox dependency versions, the backend or Navigation SDK routes.
